param(
  [string]$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path,
  [string]$OutputDir = "",
  [string]$ZipName = "",
  [string]$FileList = "",
  [string]$ModifiedSince = "",
  [string]$GitBaseRef = "HEAD",
  [switch]$IncludeUntracked,
  [switch]$UseGitOnly,
  [string[]]$IncludeRoots = @(
    "app", "src", "lib", "prisma", "services", "scripts", "components", "types",
    "data", "public", "docker", "docs", "python-services",
    "ecosystem.config.cjs", "next.config.ts", "package.json", "package-lock.json",
    "tsconfig.json", "prisma.config.ts", "middleware.ts", "Dockerfile", "docker-compose.prod.yml"
  )
)

$ErrorActionPreference = "Stop"

function Test-ExcludedPath {
  param([string]$RelativePath)
  $patterns = @(
    "\\node_modules\\",
    "\\\.next\\",
    "\\\.git\\",
    "\\\.cursor\\",
    "\\dist\\",
    "\\coverage\\",
    "\\\.turbo\\",
    "\\\.env$",
    "\\\.env\.",
    "\.log$",
    "\.tmp$",
    "\.dll\.node\.tmp"
  )
  foreach ($pattern in $patterns) {
    if ($RelativePath -match $pattern) { return $true }
  }
  return $false
}

function Get-GitChangedFiles {
  param([string]$Root, [string]$BaseRef, [switch]$Untracked)
  Push-Location $Root
  try {
    git rev-parse --is-inside-work-tree 2>$null | Out-Null
    if ($LASTEXITCODE -ne 0) { return @() }

    $files = @()
    $files += git diff --name-only --diff-filter=ACMRTUXB $BaseRef 2>$null
    $files += git diff --name-only --cached --diff-filter=ACMRTUXB 2>$null
    if ($Untracked) {
      $files += git ls-files --others --exclude-standard 2>$null
    }
    return $files | Where-Object { $_ -and $_.Trim() -ne "" } | Sort-Object -Unique
  }
  finally {
    Pop-Location
  }
}

function Get-ModifiedFiles {
  param([string]$Root, [datetime]$Since, [string[]]$Roots)
  $result = New-Object System.Collections.Generic.List[string]
  foreach ($item in $Roots) {
    $full = Join-Path $Root $item
    if (-not (Test-Path $full)) { continue }
    if (-not (Get-Item $full).PSIsContainer) {
      if ((Get-Item $full).LastWriteTime -ge $Since) {
        $result.Add($item.Replace("\", "/"))
      }
      continue
    }
    Get-ChildItem -Path $full -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
      if ($_.LastWriteTime -ge $Since) {
        $rel = $_.FullName.Substring($Root.Length).TrimStart("\", "/")
        $result.Add($rel.Replace("\", "/"))
      }
    }
  }
  return $result | Sort-Object -Unique
}

function Resolve-DeployFiles {
  param([string]$Root)
  $files = @()

  if ($FileList -and (Test-Path $FileList)) {
    $files = Get-Content $FileList | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith("#") }
  }
  elseif (Test-Path (Join-Path $Root ".git")) {
    $files = Get-GitChangedFiles -Root $Root -BaseRef $GitBaseRef -Untracked:$IncludeUntracked
    if ($UseGitOnly) { return $files }
    if ($files.Count -eq 0 -and $ModifiedSince) {
      $files = Get-ModifiedFiles -Root $Root -Since ([datetime]$ModifiedSince) -Roots $IncludeRoots
    }
  }
  elseif ($ModifiedSince) {
    $files = Get-ModifiedFiles -Root $Root -Since ([datetime]$ModifiedSince) -Roots $IncludeRoots
  }
  else {
    throw "Git repo yok. -ModifiedSince '2026-07-01' veya -FileList manifest.txt kullanin."
  }

  return $files | Where-Object {
    $_ -and -not (Test-ExcludedPath $_) -and (Test-Path (Join-Path $Root ($_ -replace "/", "\")))
  } | Sort-Object -Unique
}

$ProjectRoot = (Resolve-Path $ProjectRoot).Path
if (-not $OutputDir) {
  $OutputDir = Join-Path $ProjectRoot "deploy"
}
New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null

$timestamp = Get-Date -Format "yyyyMMdd-HHmm"
if (-not $ZipName) {
  $ZipName = "kriptopaneli-delta-$timestamp.zip"
}
$zipPath = Join-Path $OutputDir $ZipName
$manifestPath = Join-Path $OutputDir ($ZipName -replace "\.zip$", ".manifest.txt")

$relativeFiles = @(Resolve-DeployFiles -Root $ProjectRoot)
if ($relativeFiles.Count -eq 0) {
  throw "Zip icin dosya bulunamadi."
}

$stagingRoot = Join-Path $env:TEMP "kriptopaneli-deploy-$timestamp"
if (Test-Path $stagingRoot) {
  Remove-Item $stagingRoot -Recurse -Force
}
New-Item -ItemType Directory -Force -Path $stagingRoot | Out-Null

$copied = 0
$missing = New-Object System.Collections.Generic.List[string]
foreach ($rel in $relativeFiles) {
  $src = Join-Path $ProjectRoot ($rel -replace "/", "\")
  if (-not (Test-Path $src)) {
    $missing.Add($rel)
    continue
  }
  $dest = Join-Path $stagingRoot ($rel -replace "/", "\")
  $destDir = Split-Path $dest -Parent
  New-Item -ItemType Directory -Force -Path $destDir | Out-Null
  Copy-Item -Path $src -Destination $dest -Force
  $copied++
}

$relativeFiles | Set-Content -Path $manifestPath -Encoding UTF8

if (Test-Path $zipPath) {
  Remove-Item $zipPath -Force
}

Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory($stagingRoot, $zipPath, [System.IO.Compression.CompressionLevel]::Optimal, $false)

Remove-Item $stagingRoot -Recurse -Force

$zipSizeMb = [math]::Round((Get-Item $zipPath).Length / 1MB, 2)

Write-Host ""
Write-Host "VPS deploy zip hazir."
Write-Host "  Proje     : $ProjectRoot"
Write-Host "  Zip       : $zipPath"
Write-Host "  Manifest  : $manifestPath"
Write-Host "  Dosya     : $copied"
Write-Host "  Eksik     : $($missing.Count)"
Write-Host "  Boyut     : $zipSizeMb MB"
Write-Host ""
Write-Host "VPS hedef   : /var/www/kriptopaneli"
Write-Host "Ornek kurulum:"
Write-Host "  scp `"$zipPath`" root@76.13.138.159:/tmp/"
Write-Host "  ssh root@76.13.138.159 'cd /var/www/kriptopaneli && unzip -o /tmp/$ZipName'"
Write-Host ""

if ($missing.Count -gt 0) {
  Write-Warning "Eksik dosyalar manifestte listelenmedi; kopyalanamadi: $($missing.Count)"
}
